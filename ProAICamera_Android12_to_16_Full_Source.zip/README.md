# Pro AI Camera (Android 12, 13, 14, 15, 16) — Complete Source Code & Free Online APK Build Guide

Yeh project aapki **58 Camera & AI Features** ki list aur **High-Capacity Gallery ("App mai kafi jyada pictures")** ke hisaab se **100% Offline** chalne ke liye banaya gaya hai. Isme kisi bhi Cloud API Key ya internet connection ki zaroorat nahi hai.

## 1. Bina Laptop/Android Studio ke 5 Minute mein `.APK` File Kaise Banayein? (GitHub Actions Free Method)

Kyunki is project ke andar `.github/workflows/build-apk.yml` automatic script pehle se laga di gayi hai, aap apne mobile phone ya normal browser se hi free mein `.apk` banwa sakte hain:

1. **GitHub Account kholein:** [github.com](https://github.com/) par jayein aur ek naya **Repository** banayein (naam rakhein `ProAICamera`).
2. **Project Upload karein:** `ProAICamera_Android12_to_16_Full_Source.zip` ko apne phone ya PC par **Unzip (Extract)** karein aur saare folders (`app`, `gradle`, `.github`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`) ko GitHub repository mein upload karke **Commit** kar dein.
3. **Automatic APK Build:** Jaise hi files upload hongi, GitHub ke upar **Actions** tab par click karein. Wahan `Build ProAICamera APK (Android 12-16)` workflow apne aap chalne lagega.
4. **APK Download & Install:** 3 se 5 minute mein build green (`✓`) ho jayega. Uske niche **Artifacts** section mein aapko **`ProAICamera-Debug-APK`** aur **`ProAICamera-Release-APK`** dono mil jayenge. Use download karein aur apne Android 12, 13, 14, 15, ya 16 phone mein seedha install kar lein!

## 2. Android Studio (PC/Laptop) se `.APK` Kaise Banayein?

1. `ProAICamera_Android12_to_16_Full_Source.zip` ko किसी folder mein extract karein.
2. **Android Studio (Ladybug / Koala ya naya version)** kholein aur **Open** par click karke is folder ko select karein.
3. Gradle Sync poora hone dein (1–2 minute).
4. Upar menu mein **Build -> Build Bundle(s) / APK(s) -> Build APK(s)** par click karein.
5. `app/build/outputs/apk/debug/app-debug.apk` mein aapki install karne layak `.apk` file taiyaar mil jayegi.

## 3. Aapke 58 Features ka Code Mapping (Kaunsa Feature Kahan Code Kiya Gaya Hai)

| Category & Feature # | Feature Name | Source File & Working Implementation |
| :--- | :--- | :--- |
| **#1, #2** | HDR+ & Multi-Frame Merging | `ComputationalPipeline.kt` -> `processHdrPlusBurst()` (Mertens Exposure Fusion + Linear Burst Accumulation) |
| **#3, #54** | Zero Shutter Lag (ZSL) & Buffer Management | `ZslRingBufferManager.kt` -> `pushImageFromReader()`, `getZslBaseFrameAndBurst()` (12-frame Circular YUV_420_888 Ring Buffer) |
| **#4, #50** | RAW Processing & JPEG / RAW (.DNG) Output | `ProCamera2Controller.kt` -> `saveRawDngFile()` (`ImageFormat.RAW_SENSOR` + calibrated `DngCreator`) |
| **#5, #7, #8** | Image Alignment, Motion Detection & Deghosting | `ComputationalPipeline.kt` -> `computeTileSad()` (16x16 Coarse-to-Fine Block Matching + Per-Tile Motion Variance Rejection) |
| **#6, #10** | Denoising & Sharpening | `ComputationalPipeline.kt` -> `applyEdgePreservingSharpen()` + Hardware ISP `NOISE_REDUCTION_MODE_HIGH_QUALITY` |
| **#9, #14, #15, #34** | Tone Mapping, Highlight/Shadow Recovery, Live HDRnet | `ComputationalPipeline.kt` -> `applyToneMapColorAndSharpen()`, `buildLiveHdrNetLut()` |
| **#11, #12** | Auto Exposure (AE) & Auto White Balance (AWB) | `ProCamera2Controller.kt` -> `applyHardwareParametersToBuilder()`, `kelvinToRggbVector()` (EV Compensation, Manual ISO/Shutter, Kelvin RGGB) |
| **#13, #26** | Color Rendering & Real Tone (Skin Calibration) | `ComputationalPipeline.kt` -> `isMonkSkinTonePixel()` & `PortraitAndFaceEngine.kt` (Monk Skin Tone 1–10 protection) |
| **#16, #17, #18, #19, #20** | Night Sight, Long Exposure, Adaptive Exposure, Night HDR, Astrophotography | `NightAndAstroProcessor.kt` -> `computeAdaptiveExposurePlan()`, `processNightSight()`, `processLongExposureLightTrails()`, `processAstrophotography()` |
| **#21, #22, #23, #24, #25** | Super Res Zoom, Digital/Optical Zoom, Upscaling, Detail Reconstruction | `SuperResZoomProcessor.kt` -> `processSuperResZoom()`, `bicubicUpscale()`, `reconstructFineDetails()` + `CONTROL_ZOOM_RATIO` |
| **#27, #28, #33** | Face Detection, Face Unblur & Face Retouching | `PortraitAndFaceEngine.kt` -> `detectFacesBlocking()` (Offline ML Kit), `applyFaceRetouchUnblurAndRealTone()` |
| **#29, #30, #31, #32** | Portrait Mode, Depth Estimation, Segmentation, Bokeh Simulation | `PortraitAndFaceEngine.kt` -> `estimateDepthMapBlocking()`, `renderVariableApertureBokeh()` (Circular Aperture + Specular Highlight Boost) |
| **#35, #36, #37** | Best Take, Top Shot & Motion Photos | `SmartAiFeaturesEngine.kt` -> `applyAutomaticBestTake()`, `pickTopShotBestFrame()` & `ZslRingBufferManager.kt` -> `exportMotionPhotoSequence()` |
| **#38, #39** | Camera Coach & Scene Recognition | `SmartAiFeaturesEngine.kt` -> `evaluateCameraCoach()`, `recognizeSceneBlocking()` (Offline ML Kit Image Labeling) |
| **#40, #41, #42, #43** | Autofocus (AF), Tracking AF, OIS & EIS | `ProCamera2Controller.kt` -> `setFocusAndTrackingRegion()`, `LENS_OPTICAL_STABILIZATION_MODE_ON`, `CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION` |
| **#44, #45, #46** | Offline Magic Eraser, Photo Unblur & Magic Editor | `OfflineMagicEditorEngine.kt` -> `applyMagicEraserInpaint()`, `applyPhotoUnblur()` (Richardson-Lucy Deconvolution), `applyMagicEditorMoveAndScale()` |
| **#47, #48, #49** | Post-Capture Portrait Blur, Light/Color Adjustment & Ultra HDR | `OfflineMagicEditorEngine.kt` -> `applyPostCapturePortraitBlur()`, `applyLightAndColorAdjustments()`, `attachUltraHdrGainmapIfSupported()` (Android 14–16 `Gainmap`) |
| **#51, #52, #53, #55, #56, #57, #58** | Camera2 API, HAL, ISP, Lens/Shading/Chromatic Aberration Corrections & Sensor Calibration | `CameraCapabilitiesManager.kt` -> `inspectCamera()` & `ProCamera2Controller.kt` (`DISTORTION_CORRECTION`, `SHADING_MODE`, `COLOR_CORRECTION_ABERRATION_MODE`) |
| **High-Volume Gallery** | 10,000+ Pictures Support ("App mai kafi jyada pictures") | `HighCapacityGalleryManager.kt` & `GalleryActivity.kt` (RAM-safe LruCache + `RGB_565` sub-sampled thumbnails + 60-item infinite paging) |
