plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.proaicamera.gcamx"
    compileSdk = 35 // Supports Android 12 (31), 13 (33), 14 (34), 15 (35) & forward-compatible with Android 16 (36)

    defaultConfig {
        applicationId = "com.proaicamera.gcamx"
        minSdk = 31 // Android 12+
        targetSdk = 35 // Android 15 / 16 ready
        versionCode = 1
        versionName = "1.0.0-OfflinePro"

        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Sign release build with debug key by default so user can install APK directly
            signingConfig = signingConfigs.getByName("debug")
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    // AndroidX Core & UI
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")

    // Kotlin Coroutines for parallel Multi-Frame Stacking & High-Capacity Gallery Loading
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // 100% Offline On-Device Google ML Kit (Bundled inside APK, no internet required)
    // Feature #27 (Face Detection), #35 (Best Take), #36 (Top Shot Eye/Smile scoring)
    implementation("com.google.mlkit:face-detection:16.1.7")
    // Feature #29, #30, #31, #32 (Portrait Segmentation, Depth & Bokeh), #46 (Magic Editor Subject Cutout)
    implementation("com.google.mlkit:segmentation-selfie:16.0.0-beta6")
    // Feature #39 (Scene Recognition)
    implementation("com.google.mlkit:image-labeling:17.0.9")
}
