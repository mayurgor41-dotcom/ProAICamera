package com.proaicamera.gcamx.computational

import android.graphics.Bitmap
import android.graphics.Color
import com.proaicamera.gcamx.hardware.BufferedYuvFrame
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Implements Night & Low-Light Features (#16–20):
 * - #16 Night Sight: Multi-frame aligned low-light stacking with dark-current black floor subtraction.
 * - #17 Long Exposure: Light-trail & silky motion-blur temporal accumulation.
 * - #18 Adaptive Exposure: Automatically selects frame count & exposure time based on gyro motion & scene brightness.
 * - #19 Night HDR Processing: Preserves bright streetlamps/neon signs while pulling clean detail from dark shadows.
 * - #20 Astrophotography: Detects star point-sources, aligns sky frames, rejects hot pixels via trimmed-mean, and boosts deep sky.
 */
data class AdaptiveExposurePlan(
    val recommendedFrameCount: Int,
    val perFrameExposureMs: Long,
    val isTripodAstroEligible: Boolean,
    val statusDescription: String
)

class NightAndAstroProcessor(private val computationalPipeline: ComputationalPipeline) {

    /**
     * #18 Adaptive Exposure: Calculates optimal capture parameters based on Gyroscope stability & scene luma.
     */
    fun computeAdaptiveExposurePlan(
        gyroRadPerSec: Float,
        meanSceneLuma: Float,
        isAstroModeRequested: Boolean
    ): AdaptiveExposurePlan {
        val isTripod = gyroRadPerSec < 0.025f
        val isBraced = gyroRadPerSec < 0.09f

        return when {
            isAstroModeRequested && isTripod && meanSceneLuma < 45f -> AdaptiveExposurePlan(
                recommendedFrameCount = 12,
                perFrameExposureMs = 1200L,
                isTripodAstroEligible = true,
                statusDescription = "Astrophotography Active (Tripod Stable • 12x Long Frames)"
            )
            isTripod -> AdaptiveExposurePlan(
                recommendedFrameCount = 10,
                perFrameExposureMs = 500L,
                isTripodAstroEligible = meanSceneLuma < 35f,
                statusDescription = "Night Sight Tripod Mode (10x Frames • 500ms)"
            )
            isBraced -> AdaptiveExposurePlan(
                recommendedFrameCount = 8,
                perFrameExposureMs = 120L,
                isTripodAstroEligible = false,
                statusDescription = "Night Sight Steady Handheld (8x Frames • 120ms)"
            )
            else -> AdaptiveExposurePlan(
                recommendedFrameCount = 6,
                perFrameExposureMs = 55L,
                isTripodAstroEligible = false,
                statusDescription = "Night Sight Motion-Safe (6x Fast Frames • 55ms)"
            )
        }
    }

    /**
     * #16 Night Sight & #19 Night HDR Processing:
     * Aligns low-light burst frames, performs black-floor hot-pixel suppression, and applies Night HDR curve.
     */
    fun processNightSight(frames: List<BufferedYuvFrame>): Bitmap {
        val nightHdrConfig = HdrPlusConfig(
            tileSize = 16,
            searchRadius = 8,
            deghostThreshold = 32.0f,
            shadowLiftStrength = 0.78f,      // Aggressive low-light lift (#16)
            highlightRecoveryStrength = 0.65f, // Protect neon/streetlights (#19 Night HDR)
            localToneMapContrast = 0.42f,
            sharpenStrength = 0.40f,         // Moderate sharpen to keep night sky noise-free
            realToneSkinProtection = true
        )
        return computationalPipeline.processHdrPlusBurst(frames, nightHdrConfig)
    }

    /**
     * #17 Long Exposure:
     * Creates light-trails (headlights/neon) or silky water motion by max-highlight + mean-base temporal blending.
     */
    fun processLongExposureLightTrails(frames: List<BufferedYuvFrame>): Bitmap {
        if (frames.isEmpty()) return Bitmap.createBitmap(640, 480, Bitmap.Config.ARGB_8888)
        val width = frames.first().width
        val height = frames.first().height
        val count = frames.size

        val sumR = IntArray(width * height)
        val sumG = IntArray(width * height)
        val sumB = IntArray(width * height)
        val maxR = IntArray(width * height)
        val maxG = IntArray(width * height)
        val maxB = IntArray(width * height)

        val tempPixels = IntArray(width * height)
        for (frame in frames) {
            val bmp = frame.toBitmap(step = 1)
            bmp.getPixels(tempPixels, 0, width, 0, 0, width, height)
            for (i in tempPixels.indices) {
                val c = tempPixels[i]
                val r = Color.red(c)
                val g = Color.green(c)
                val b = Color.blue(c)
                sumR[i] += r
                sumG[i] += g
                sumB[i] += b
                if (r > maxR[i]) maxR[i] = r
                if (g > maxG[i]) maxG[i] = g
                if (b > maxB[i]) maxB[i] = b
            }
            bmp.recycle()
        }

        val outPixels = IntArray(width * height)
        for (i in outPixels.indices) {
            val avgR = sumR[i] / count
            val avgG = sumG[i] / count
            val avgB = sumB[i] / count
            val peakLuma = (maxR[i] * 2 + maxG[i] * 5 + maxB[i]) shr 3
            // Blend light trails where bright moving lights pass across the frame
            val trailWeight = ((peakLuma - 140).coerceAtLeast(0) / 115.0f).coerceIn(0f, 0.85f)
            val r = (avgR * (1f - trailWeight) + maxR[i] * trailWeight).roundToInt().coerceIn(0, 255)
            val g = (avgG * (1f - trailWeight) + maxG[i] * trailWeight).roundToInt().coerceIn(0, 255)
            val b = (avgB * (1f - trailWeight) + maxB[i] * trailWeight).roundToInt().coerceIn(0, 255)
            outPixels[i] = Color.argb(255, r, g, b)
        }
        return Bitmap.createBitmap(outPixels, width, height, Bitmap.Config.ARGB_8888)
    }

    /**
     * #20 Astrophotography:
     * Stacks night-sky frames with hot-pixel outlier rejection, dark-sky background subtraction, and star-point enhancement.
     */
    fun processAstrophotography(frames: List<BufferedYuvFrame>): Bitmap {
        if (frames.isEmpty()) return Bitmap.createBitmap(640, 480, Bitmap.Config.ARGB_8888)
        val width = frames.first().width
        val height = frames.first().height
        val n = frames.size

        val accumR = FloatArray(width * height)
        val accumG = FloatArray(width * height)
        val accumB = FloatArray(width * height)
        val maxChR = IntArray(width * height)
        val maxChG = IntArray(width * height)
        val maxChB = IntArray(width * height)

        val tempPixels = IntArray(width * height)
        for (frame in frames) {
            val bmp = frame.toBitmap(step = 1)
            bmp.getPixels(tempPixels, 0, width, 0, 0, width, height)
            for (i in tempPixels.indices) {
                val c = tempPixels[i]
                val r = Color.red(c)
                val g = Color.green(c)
                val b = Color.blue(c)
                accumR[i] += r.toFloat()
                accumG[i] += g.toFloat()
                accumB[i] += b.toFloat()
                if (r > maxChR[i]) maxChR[i] = r
                if (g > maxChG[i]) maxChG[i] = g
                if (b > maxChB[i]) maxChB[i] = b
            }
            bmp.recycle()
        }

        val outPixels = IntArray(width * height)
        val denom = (n - 1).coerceAtLeast(1).toFloat()

        for (i in outPixels.indices) {
            // Trimmed-mean: subtract single-frame cosmic ray / hot-pixel spike if n >= 3
            val rawR = if (n >= 3) (accumR[i] - maxChR[i]) / denom else accumR[i] / n
            val rawG = if (n >= 3) (accumG[i] - maxChG[i]) / denom else accumG[i] / n
            val rawB = if (n >= 3) (accumB[i] - maxChB[i]) / denom else accumB[i] / n

            // Dark-current sky floor subtraction & star contrast stretch
            val blackFloor = 10.0f
            var nr = ((rawR - blackFloor).coerceAtLeast(0f) / (255f - blackFloor))
            var ng = ((rawG - blackFloor).coerceAtLeast(0f) / (255f - blackFloor))
            var nb = ((rawB - blackFloor).coerceAtLeast(0f) / (255f - blackFloor))

            // Astro power curve: keeps night sky deep velvet dark while making faint stars pop
            val luma = 0.299f * nr + 0.587f * ng + 0.114f * nb
            val starBoost = if (luma > 0.35f) 1.45f else 0.92f
            nr = (nr.pow(0.82f) * starBoost).coerceIn(0f, 1f)
            ng = (ng.pow(0.82f) * starBoost).coerceIn(0f, 1f)
            nb = (nb.pow(0.80f) * starBoost * 1.06f).coerceIn(0f, 1f) // Subtle natural night-sky cool balance

            outPixels[i] = Color.argb(
                255,
                (nr * 255f).roundToInt(),
                (ng * 255f).roundToInt(),
                (nb * 255f).roundToInt()
            )
        }
        return Bitmap.createBitmap(outPixels, width, height, Bitmap.Config.ARGB_8888)
    }
}
