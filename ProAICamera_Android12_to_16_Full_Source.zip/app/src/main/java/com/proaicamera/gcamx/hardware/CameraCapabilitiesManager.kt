package com.proaicamera.gcamx.hardware

import android.content.Context
import android.graphics.ImageFormat
import android.graphics.Rect
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.os.Build
import android.util.Range
import android.util.Rational
import android.util.Size

/**
 * Covers Technical Systems & Zoom Hardware Capabilities:
 * - #51 Camera2 API capability querying
 * - #52 Camera HAL Hardware Level inspection (LEGACY, LIMITED, FULL, LEVEL_3)
 * - #53 Image Signal Processor (ISP) Reprocessing & 10-bit / Ultra HDR pipeline detection
 * - #55 Lens Correction capability check
 * - #56 Lens Shading Correction map check
 * - #57 Chromatic Aberration Correction check
 * - #58 Sensor Calibration (Black level, ISO range, Shutter time range, Active Array, Color Matrices)
 * - #22 Digital Zoom & #23 Optical Zoom (Multi-focal physical lens discovery: 0.6x Ultrawide, 1x Wide, 2x/3x/5x Telephoto)
 */
data class CameraHardwareProfile(
    val cameraId: String,
    val lensFacing: Int,
    val halLevelName: String,
    val supportsRawSensor: Boolean,
    val supportsZslPrivateReprocessing: Boolean,
    val supportsYuvReprocessing: Boolean,
    val supportsUltraHdrJpegR: Boolean,
    val supportsLowLightBoostIsp: Boolean,
    val supportsOis: Boolean,
    val supportsEis: Boolean,
    val supportsPreviewStabilization: Boolean,
    val supportsLensDistortionCorrection: Boolean,
    val supportsLensShadingMap: Boolean,
    val supportsChromaticAberrationCorrection: Boolean,
    val isoRange: Range<Int>,
    val exposureTimeRangeNs: Range<Long>,
    val compensationRange: Range<Int>,
    val compensationStep: Rational,
    val maxZoomRatio: Float,
    val minZoomRatio: Float,
    val focalLengthsMm: FloatArray,
    val physicalCameraIds: Set<String>,
    val activeArrayRect: Rect,
    val blackLevelPattern: IntArray,
    val maxJpegSize: Size,
    val maxYuvSize: Size,
    val maxRawSize: Size?
)

class CameraCapabilitiesManager(context: Context) {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    fun inspectCamera(cameraId: String): CameraHardwareProfile {
        val chars = cameraManager.getCameraCharacteristics(cameraId)
        val facing = chars.get(CameraCharacteristics.LENS_FACING) ?: CameraCharacteristics.LENS_FACING_BACK

        // #52 Camera HAL Level
        val halLevel = chars.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)
        val halLevelName = when (halLevel) {
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "HAL3_LEVEL_3 (Full RAW + YUV Reprocessing)"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "HAL3_FULL (Per-Frame Manual ISP)"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "HAL3_LIMITED"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "HAL3_EXTERNAL"
            else -> "HAL_LEGACY"
        }

        // #53 ISP Capabilities
        val caps = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
        val supportsRaw = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)
        val supportsZslPriv = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_PRIVATE_REPROCESSING)
        val supportsYuvReproc = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_YUV_REPROCESSING)

        // #49 Ultra HDR (JPEG_R on Android 14 / API 34+)
        val configMap = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val supportsUltraHdr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            configMap?.outputFormats?.contains(ImageFormat.JPEG_R) == true
        } else {
            false
        }

        // Android 15 / 16 ISP Low-Light Boost AE Mode check
        val aeModes = chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES) ?: IntArray(0)
        val supportsLowLightBoost = aeModes.any { it == 6 } // CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY = 6 (API 35+)

        // #42 OIS & #43 EIS
        val oisModes = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION) ?: IntArray(0)
        val supportsOis = oisModes.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON)

        val videoStabModes = chars.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES) ?: IntArray(0)
        val supportsEis = videoStabModes.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON)
        val supportsPreviewStab = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            videoStabModes.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION)
        } else false

        // #55 Lens Correction
        val distortionModes = chars.get(CameraCharacteristics.DISTORTION_CORRECTION_AVAILABLE_MODES) ?: IntArray(0)
        val supportsDistortion = distortionModes.contains(CameraMetadata.DISTORTION_CORRECTION_MODE_HIGH_QUALITY)

        // #56 Lens Shading Correction
        val shadingModes = chars.get(CameraCharacteristics.SHADING_AVAILABLE_MODES) ?: IntArray(0)
        val supportsShading = shadingModes.contains(CameraMetadata.SHADING_MODE_HIGH_QUALITY)

        // #57 Chromatic Aberration Correction
        val caModes = chars.get(CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES) ?: IntArray(0)
        val supportsCa = caModes.contains(CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY)

        // #58 Sensor Calibration parameters
        val isoRange = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 3200)
        val expRange = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(100_000L, 1_000_000_000L)
        val compRange = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: Range(-12, 12)
        val compStep = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP) ?: Rational(1, 3)
        val activeRect = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: Rect(0, 0, 4000, 3000)

        val blackLevel = IntArray(4) { 64 }
        chars.get(CameraCharacteristics.SENSOR_BLACK_LEVEL_PATTERN)?.copyTo(blackLevel, 0)

        // #22 Digital Zoom & #23 Optical Zoom
        val zoomRange = chars.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
        val minZoom = zoomRange?.lower ?: 1.0f
        val maxZoom = zoomRange?.upper ?: (chars.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 8.0f)
        val focalLengths = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS) ?: floatArrayOf(4.25f)
        val physicalIds = chars.physicalCameraIds

        val jpegSizes = configMap?.getOutputSizes(ImageFormat.JPEG) ?: arrayOf(Size(1920, 1080))
        val yuvSizes = configMap?.getOutputSizes(ImageFormat.YUV_420_888) ?: arrayOf(Size(1920, 1080))
        val rawSizes = if (supportsRaw) configMap?.getOutputSizes(ImageFormat.RAW_SENSOR) else null

        val maxJpeg = jpegSizes.maxByOrNull { it.width.toLong() * it.height.toLong() } ?: Size(1920, 1080)
        val maxYuv = yuvSizes
            .filter { it.width <= 4096 && it.height <= 3072 }
            .maxByOrNull { it.width.toLong() * it.height.toLong() } ?: yuvSizes.first()
        val maxRaw = rawSizes?.maxByOrNull { it.width.toLong() * it.height.toLong() }

        return CameraHardwareProfile(
            cameraId = cameraId,
            lensFacing = facing,
            halLevelName = halLevelName,
            supportsRawSensor = supportsRaw,
            supportsZslPrivateReprocessing = supportsZslPriv,
            supportsYuvReprocessing = supportsYuvReproc,
            supportsUltraHdrJpegR = supportsUltraHdr,
            supportsLowLightBoostIsp = supportsLowLightBoost,
            supportsOis = supportsOis,
            supportsEis = supportsEis,
            supportsPreviewStabilization = supportsPreviewStab,
            supportsLensDistortionCorrection = supportsDistortion,
            supportsLensShadingMap = supportsShading,
            supportsChromaticAberrationCorrection = supportsCa,
            isoRange = isoRange,
            exposureTimeRangeNs = expRange,
            compensationRange = compRange,
            compensationStep = compStep,
            maxZoomRatio = maxZoom,
            minZoomRatio = minZoom,
            focalLengthsMm = focalLengths,
            physicalCameraIds = physicalIds,
            activeArrayRect = activeRect,
            blackLevelPattern = blackLevel,
            maxJpegSize = maxJpeg,
            maxYuvSize = maxYuv,
            maxRawSize = maxRaw
        )
    }

    fun findPrimaryBackCameraId(): String {
        for (id in cameraManager.cameraIdList) {
            val chars = cameraManager.getCameraCharacteristics(id)
            if (chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK) {
                return id
            }
        }
        return cameraManager.cameraIdList.firstOrNull() ?: "0"
    }

    fun findPrimaryFrontCameraId(): String {
        for (id in cameraManager.cameraIdList) {
            val chars = cameraManager.getCameraCharacteristics(id)
            if (chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT) {
                return id
            }
        }
        return findPrimaryBackCameraId()
    }
}
