package com.proaicamera.gcamx.ui

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.roundToInt

/**
 * Custom interactive Canvas View for EditorActivity supporting:
 * - Brush painting mask for #44 Magic Eraser
 * - Subject drag vector (shiftX, shiftY) for #46 Magic Editor
 * - Tap focal point (normX, normY) for #47 Post-Capture Portrait Blur
 */
class BrushCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class InteractionMode {
        BRUSH_MASK,
        DRAG_SUBJECT,
        TAP_FOCUS_POINT
    }

    var interactionMode: InteractionMode = InteractionMode.BRUSH_MASK

    private var imageBitmap: Bitmap? = null
    private var maskPath = Path()
    private val maskPoints = mutableListOf<PointF>()
    var brushRadiusPx: Float = 42f

    var lastTapNormX: Float = 0.5f
        private set
    var lastTapNormY: Float = 0.5f
        private set

    var dragDeltaX: Float = 0f
        private set
    var dragDeltaY: Float = 0f
        private set

    private var touchStartX = 0f
    private var touchStartY = 0f

    private val brushPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(140, 0, 229, 255)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = brushRadiusPx
    }

    private val focusRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    fun setBitmap(bmp: Bitmap) {
        imageBitmap = bmp
        clearMask()
        invalidate()
    }

    fun getBitmap(): Bitmap? = imageBitmap

    fun clearMask() {
        maskPath.reset()
        maskPoints.clear()
        dragDeltaX = 0f
        dragDeltaY = 0f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = imageBitmap ?: return

        val dstRect = computeDisplayRect(bmp.width, bmp.height, width, height)
        canvas.drawBitmap(bmp, null, dstRect, null)

        if (interactionMode == InteractionMode.BRUSH_MASK) {
            brushPaint.strokeWidth = brushRadiusPx
            canvas.drawPath(maskPath, brushPaint)
        } else if (interactionMode == InteractionMode.TAP_FOCUS_POINT) {
            val fx = dstRect.left + lastTapNormX * dstRect.width()
            val fy = dstRect.top + lastTapNormY * dstRect.height()
            canvas.drawCircle(fx, fy, 36f, focusRingPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val bmp = imageBitmap ?: return false
        val dstRect = computeDisplayRect(bmp.width, bmp.height, width, height)

        when (interactionMode) {
            InteractionMode.BRUSH_MASK -> {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        maskPath.moveTo(event.x, event.y)
                        recordMaskPoint(event.x, event.y, dstRect)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        maskPath.lineTo(event.x, event.y)
                        recordMaskPoint(event.x, event.y, dstRect)
                    }
                }
                invalidate()
                return true
            }
            InteractionMode.DRAG_SUBJECT -> {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        touchStartX = event.x
                        touchStartY = event.y
                    }
                    MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                        val scaleX = bmp.width.toFloat() / dstRect.width().coerceAtLeast(1f)
                        val scaleY = bmp.height.toFloat() / dstRect.height().coerceAtLeast(1f)
                        dragDeltaX = (event.x - touchStartX) * scaleX
                        dragDeltaY = (event.y - touchStartY) * scaleY
                    }
                }
                invalidate()
                return true
            }
            InteractionMode.TAP_FOCUS_POINT -> {
                if (event.action == MotionEvent.ACTION_DOWN) {
                    lastTapNormX = ((event.x - dstRect.left) / dstRect.width().coerceAtLeast(1f)).coerceIn(0f, 1f)
                    lastTapNormY = ((event.y - dstRect.top) / dstRect.height().coerceAtLeast(1f)).coerceIn(0f, 1f)
                    invalidate()
                }
                return true
            }
        }
    }

    /**
     * Converts painted screen points into a boolean mask matching the exact Bitmap dimensions.
     */
    fun buildBitmapMask(): BooleanArray {
        val bmp = imageBitmap ?: return BooleanArray(0)
        val w = bmp.width
        val h = bmp.height
        val mask = BooleanArray(w * h)
        if (maskPoints.isEmpty()) return mask

        val dstRect = computeDisplayRect(w, h, width, height)
        val radiusInBmp = ((brushRadiusPx / dstRect.width().coerceAtLeast(1f)) * w).roundToInt().coerceAtLeast(6)
        val rSq = radiusInBmp * radiusInBmp

        for (pt in maskPoints) {
            val bx = (pt.x * w).roundToInt().coerceIn(0, w - 1)
            val by = (pt.y * h).roundToInt().coerceIn(0, h - 1)

            val top = (by - radiusInBmp).coerceAtLeast(0)
            val bottom = (by + radiusInBmp).coerceAtMost(h - 1)
            val left = (bx - radiusInBmp).coerceAtLeast(0)
            val right = (bx + radiusInBmp).coerceAtMost(w - 1)

            for (y in top..bottom) {
                val dy = y - by
                val row = y * w
                for (x in left..right) {
                    val dx = x - bx
                    if (dx * dx + dy * dy <= rSq) {
                        mask[row + x] = true
                    }
                }
            }
        }
        return mask
    }

    private fun recordMaskPoint(screenX: Float, screenY: Float, dstRect: RectF) {
        val normX = ((screenX - dstRect.left) / dstRect.width().coerceAtLeast(1f)).coerceIn(0f, 1f)
        val normY = ((screenY - dstRect.top) / dstRect.height().coerceAtLeast(1f)).coerceIn(0f, 1f)
        maskPoints.add(PointF(normX, normY))
    }

    private fun computeDisplayRect(bmpW: Int, bmpH: Int, viewW: Int, viewH: Int): RectF {
        if (viewW <= 0 || viewH <= 0) return RectF(0f, 0f, bmpW.toFloat(), bmpH.toFloat())
        val scale = minOf(viewW.toFloat() / bmpW, viewH.toFloat() / bmpH)
        val drawW = bmpW * scale
        val drawH = bmpH * scale
        val left = (viewW - drawW) / 2f
        val top = (viewH - drawH) / 2f
        return RectF(left, top, left + drawW, top + drawH)
    }
}
