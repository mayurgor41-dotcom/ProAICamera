package com.proaicamera.gcamx.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.proaicamera.gcamx.R
import com.proaicamera.gcamx.ai.PortraitAndFaceEngine
import com.proaicamera.gcamx.editor.ColorAdjustmentParams
import com.proaicamera.gcamx.editor.OfflineMagicEditorEngine
import com.proaicamera.gcamx.gallery.HighCapacityGalleryManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Offline Magic Studio Activity implementing:
 * - #44 Magic Eraser (Brush over object & erase offline)
 * - #45 Photo Unblur (Richardson-Lucy deconvolution sharpening)
 * - #46 Magic Editor (Cutout subject, inpaint background & reposition/scale)
 * - #47 Portrait Blur (Post-capture depth bokeh & tap-to-refocus)
 * - #48 Light / Color Adjustment (Exposure, Contrast, Saturation, Warmth, Shadows/Highlights)
 * - #49 Ultra HDR Gainmap Save (Android 14–16)
 */
class EditorActivity : AppCompatActivity() {

    private lateinit var brushCanvas: BrushCanvasView
    private lateinit var tvEditorStatus: TextView
    private lateinit var seekIntensity: SeekBar

    private lateinit var portraitEngine: PortraitAndFaceEngine
    private lateinit var magicEditorEngine: OfflineMagicEditorEngine
    private lateinit var galleryManager: HighCapacityGalleryManager

    private var currentBitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor)

        brushCanvas = findViewById(R.id.brushCanvasView)
        tvEditorStatus = findViewById(R.id.tvEditorStatus)
        seekIntensity = findViewById(R.id.seekEditorIntensity)

        portraitEngine = PortraitAndFaceEngine()
        magicEditorEngine = OfflineMagicEditorEngine(portraitEngine)
        galleryManager = HighCapacityGalleryManager(this)

        loadInitialPhoto()
        setupEditorTools()
    }

    private fun loadInitialPhoto() {
        val explicitPath = intent.getStringExtra("PHOTO_PATH")
        val targetFile = if (explicitPath != null && File(explicitPath).exists()) {
            File(explicitPath)
        } else {
            galleryManager.loadPhotoPage(0, 1).firstOrNull()?.file
        }

        if (targetFile != null && targetFile.exists()) {
            val bmp = BitmapFactory.decodeFile(targetFile.absolutePath)
            if (bmp != null) {
                currentBitmap = bmp
                brushCanvas.setBitmap(bmp)
                tvEditorStatus.text = "Loaded: ${targetFile.name} • Brush over object for Magic Eraser"
                return
            }
        }

        // Create demo sample canvas if no photo taken yet
        val sample = Bitmap.createBitmap(800, 600, Bitmap.Config.ARGB_8888)
        sample.eraseColor(android.graphics.Color.rgb(35, 48, 68))
        currentBitmap = sample
        brushCanvas.setBitmap(sample)
        tvEditorStatus.text = "Ready • Brush on image to test Offline Magic Eraser / Unblur"
    }

    private fun setupEditorTools() {
        // #44 Magic Eraser
        findViewById<Button>(R.id.btnToolMagicEraser).setOnClickListener {
            val bmp = currentBitmap ?: return@setOnClickListener
            brushCanvas.interactionMode = BrushCanvasView.InteractionMode.BRUSH_MASK
            val mask = brushCanvas.buildBitmapMask()
            if (!mask.any { it }) {
                tvEditorStatus.text = "Magic Eraser (#44): Pehle photo par ungli se us cheez ko paint karein jise hatana hai!"
                return@setOnClickListener
            }
            tvEditorStatus.text = "Magic Eraser (#44): Removing object offline..."
            lifecycleScope.launch(Dispatchers.Default) {
                val result = magicEditorEngine.applyMagicEraserInpaint(bmp, mask)
                withContext(Dispatchers.Main) {
                    currentBitmap = result
                    brushCanvas.setBitmap(result)
                    tvEditorStatus.text = "Magic Eraser (#44) Complete!"
                }
            }
        }

        // #45 Photo Unblur
        findViewById<Button>(R.id.btnToolUnblur).setOnClickListener {
            val bmp = currentBitmap ?: return@setOnClickListener
            val strength = (seekIntensity.progress / 100.0f).coerceIn(0.3f, 1.0f)
            tvEditorStatus.text = "Photo Unblur (#45): Running Deconvolution..."
            lifecycleScope.launch(Dispatchers.Default) {
                val result = magicEditorEngine.applyPhotoUnblur(bmp, iterations = 4, strength = strength)
                withContext(Dispatchers.Main) {
                    currentBitmap = result
                    brushCanvas.setBitmap(result)
                    tvEditorStatus.text = "Photo Unblur & Face Unblur (#28, #45) Complete!"
                }
            }
        }

        // #46 Magic Editor (Cutout & Move/Scale Subject)
        findViewById<Button>(R.id.btnToolMagicEditor).setOnClickListener {
            val bmp = currentBitmap ?: return@setOnClickListener
            val mask = brushCanvas.buildBitmapMask()
            val scale = 0.8f + (seekIntensity.progress / 100.0f) * 0.6f
            tvEditorStatus.text = "Magic Editor (#46): Repositioning subject & inpainting background..."
            lifecycleScope.launch(Dispatchers.Default) {
                val result = magicEditorEngine.applyMagicEditorMoveAndScale(
                    source = bmp,
                    userMask = if (mask.any { it }) mask else null,
                    shiftX = 45,
                    shiftY = -25,
                    scaleFactor = scale
                )
                withContext(Dispatchers.Main) {
                    currentBitmap = result
                    brushCanvas.setBitmap(result)
                    tvEditorStatus.text = "Magic Editor (#46) Subject Repositioned!"
                }
            }
        }

        // #47 Portrait Blur (Post-Capture Depth Bokeh & Refocus)
        findViewById<Button>(R.id.btnToolPortraitBlur).setOnClickListener {
            val bmp = currentBitmap ?: return@setOnClickListener
            brushCanvas.interactionMode = BrushCanvasView.InteractionMode.TAP_FOCUS_POINT
            val blurAmt = (seekIntensity.progress / 100.0f).coerceIn(0.2f, 1.0f)
            tvEditorStatus.text = "Portrait Blur (#47): Computing 3D Depth & Circular Bokeh..."
            lifecycleScope.launch(Dispatchers.Default) {
                val result = magicEditorEngine.applyPostCapturePortraitBlur(
                    source = bmp,
                    blurStrength = blurAmt,
                    focusNormX = brushCanvas.lastTapNormX,
                    focusNormY = brushCanvas.lastTapNormY
                )
                withContext(Dispatchers.Main) {
                    currentBitmap = result
                    brushCanvas.setBitmap(result)
                    tvEditorStatus.text = "Portrait Blur (#47) Applied! Tap anywhere on photo to shift focus."
                }
            }
        }

        // #48 Light & Color Grading
        findViewById<Button>(R.id.btnToolColorGrade).setOnClickListener {
            val bmp = currentBitmap ?: return@setOnClickListener
            val intensity = (seekIntensity.progress - 50) / 50.0f // -1.0 .. +1.0
            tvEditorStatus.text = "Light & Color (#48): Applying studio tone curve..."
            lifecycleScope.launch(Dispatchers.Default) {
                val params = ColorAdjustmentParams(
                    exposureEv = intensity * 0.4f,
                    contrast = 1.12f,
                    highlights = -0.25f,
                    shadows = 0.35f,
                    saturation = 1.18f,
                    warmthShift = intensity * 0.3f
                )
                val result = magicEditorEngine.applyLightAndColorAdjustments(bmp, params)
                withContext(Dispatchers.Main) {
                    currentBitmap = result
                    brushCanvas.setBitmap(result)
                    tvEditorStatus.text = "Light & Color Adjustment (#48) Complete!"
                }
            }
        }

        // #49 Save with Ultra HDR Gainmap
        findViewById<Button>(R.id.btnSaveUltraHdr).setOnClickListener {
            val bmp = currentBitmap ?: return@setOnClickListener
            lifecycleScope.launch(Dispatchers.Default) {
                val ultraHdrBmp = magicEditorEngine.attachUltraHdrGainmapIfSupported(bmp)
                val saved = galleryManager.saveCapturedPhoto(
                    bitmap = ultraHdrBmp,
                    prefix = "EDITED_MAGIC",
                    isUltraHdr = true
                )
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        this@EditorActivity,
                        "Saved Ultra HDR (#49): ${saved.name}",
                        Toast.LENGTH_LONG
                    ).show()
                    tvEditorStatus.text = "Saved to Gallery: ${saved.name}"
                }
            }
        }
    }
}
