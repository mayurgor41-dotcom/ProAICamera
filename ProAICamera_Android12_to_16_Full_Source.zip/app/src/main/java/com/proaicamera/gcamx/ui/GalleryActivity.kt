package com.proaicamera.gcamx.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.proaicamera.gcamx.R
import com.proaicamera.gcamx.gallery.HighCapacityGalleryManager
import com.proaicamera.gcamx.gallery.PhotoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * High-Capacity Paged Gallery Activity designed to smoothly browse 10,000+ photos ("App mai kafi jyada pictures")
 * with LruCache thumbnails, infinite pagination, and filter tabs for ALL, ULTRA_HDR (#49), RAW_DNG (#50), and MOTION (#37).
 */
class GalleryActivity : AppCompatActivity() {

    private lateinit var rvGallery: RecyclerView
    private lateinit var tvGallerySummary: TextView
    private lateinit var galleryManager: HighCapacityGalleryManager
    private lateinit var adapter: PhotoGridAdapter

    private val loadedItems = mutableListOf<PhotoItem>()
    private var currentPage = 0
    private var isLoadingPage = false
    private var currentFilter = "ALL"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)

        rvGallery = findViewById(R.id.rvGalleryGrid)
        tvGallerySummary = findViewById(R.id.tvGallerySummary)
        galleryManager = HighCapacityGalleryManager(this)

        val layoutManager = GridLayoutManager(this, 3)
        rvGallery.layoutManager = layoutManager
        adapter = PhotoGridAdapter(loadedItems)
        rvGallery.adapter = adapter

        // Infinite scroll pagination for thousands of photos
        rvGallery.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                val totalVisible = layoutManager.findLastVisibleItemPosition()
                if (!isLoadingPage && totalVisible >= loadedItems.size - 12) {
                    loadNextPage()
                }
            }
        })

        findViewById<Button>(R.id.btnFilterAll).setOnClickListener { applyFilter("ALL") }
        findViewById<Button>(R.id.btnFilterUltraHdr).setOnClickListener { applyFilter("ULTRA_HDR") }
        findViewById<Button>(R.id.btnFilterRawDng).setOnClickListener { applyFilter("RAW_DNG") }
        findViewById<Button>(R.id.btnFilterMotion).setOnClickListener { applyFilter("MOTION") }

        applyFilter("ALL")
    }

    private fun applyFilter(filter: String) {
        currentFilter = filter
        currentPage = 0
        loadedItems.clear()
        adapter.notifyDataSetChanged()
        loadNextPage()
    }

    private fun loadNextPage() {
        isLoadingPage = true
        lifecycleScope.launch(Dispatchers.IO) {
            val nextBatch = galleryManager.loadPhotoPage(
                pageIndex = currentPage,
                pageSize = 60,
                filterType = currentFilter
            )
            val totalCount = galleryManager.getTotalPhotoCount()
            withContext(Dispatchers.Main) {
                if (nextBatch.isNotEmpty()) {
                    val startPos = loadedItems.size
                    loadedItems.addAll(nextBatch)
                    adapter.notifyItemRangeInserted(startPos, nextBatch.size)
                    currentPage++
                }
                tvGallerySummary.text = "Total Vault Photos: $totalCount • Filter: $currentFilter (${loadedItems.size} loaded)"
                isLoadingPage = false
            }
        }
    }

    inner class PhotoGridAdapter(private val items: List<PhotoItem>) :
        RecyclerView.Adapter<PhotoGridAdapter.PhotoViewHolder>() {

        inner class PhotoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val ivThumb: ImageView = view.findViewById(R.id.ivPhotoThumb)
            val tvBadge: TextView = view.findViewById(R.id.tvPhotoBadge)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoViewHolder {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_gallery_photo, parent, false)
            return PhotoViewHolder(v)
        }

        override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
            val item = items[position]
            val badges = mutableListOf<String>()
            if (item.isUltraHdr) badges.add("HDR")
            if (item.hasRawDngCompanion) badges.add("RAW")
            if (item.hasMotionPhotoCompanion) badges.add("MOTION")
            holder.tvBadge.text = if (badges.isEmpty()) "JPG" else badges.joinToString("+")

            holder.ivThumb.setImageBitmap(null)
            lifecycleScope.launch(Dispatchers.IO) {
                val bmp = galleryManager.loadThumbnailFast(item.file, 320, 320)
                withContext(Dispatchers.Main) {
                    holder.ivThumb.setImageBitmap(bmp)
                }
            }

            holder.itemView.setOnClickListener {
                val intent = Intent(this@GalleryActivity, EditorActivity::class.java)
                intent.putExtra("PHOTO_PATH", item.file.absolutePath)
                startActivity(intent)
            }
        }

        override fun getItemCount(): Int = items.size
    }
}
