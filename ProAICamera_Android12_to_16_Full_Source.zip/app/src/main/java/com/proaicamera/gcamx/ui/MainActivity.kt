package com.proaicamera.gcamx.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.proaicamera.gcamx.R
import com.proaicamera.gcamx.ai.PortraitAndFaceEngine
import com.proaicamera.gcamx.ai.SmartAiFeaturesEngine
import com.proaicamera.gcamx.computational.ComputationalPipeline
import com.proaicamera.gcamx.computational.NightAndAstroProcessor
import com.proaicamera.gcamx.computational.SuperResZoomProcessor
import com.proaicamera.gcamx.editor.OfflineMagicEditorEngine
import com.proaicamera.gcamx.gallery.HighCapacityGalleryManager
import com.proaicamera.gcamx.hardware.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Main Pro AI Camera Activity integrating all 58 features across Android 12, 13, 14, 15, and 16.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var textureView: TextureView
    private lateinit var tvCoachBanner: TextView
    private lateinit var tvSceneBadge: TextView
    private lateinit var tvHardwareHud: TextView
    private lateinit var btnShutter: Button
    private lateinit var btnSwitchLens: Button
    private lateinit var btnOpenGallery: Button
    private lateinit var btnOpenEditor: Button
    private lateinit var seekZoom: SeekBar
    private lateinit var seekExposureEv: SeekBar

    private lateinit var capabilitiesManager: CameraCapabilitiesManager
    private lateinit var ringBufferManager: ZslRingBufferManager
    private lateinit var cameraController: ProCamera2Controller
    private lateinit var computationalPipeline: ComputationalPipeline
    private lateinit var nightAstroProcessor: NightAndAstroProcessor
    private lateinit var superResProcessor: SuperResZoomProcessor
    private lateinit var portraitFaceEngine: PortraitAndFaceEngine
    private lateinit var smartAiEngine: SmartAiFeaturesEngine
    private lateinit var magicEditorEngine: OfflineMagicEditorEngine
    private lateinit var galleryManager: HighCapacityGalleryManager

    private var previewSurface: Surface? = null
    private var isBackCamera = true
    private var aiCoachJob: Job? = null
    private var lastSavedFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textureView = findViewById(R.id.textureViewPreview)
        tvCoachBanner = findViewById(R.id.tvCoachBanner)
        tvSceneBadge = findViewById(R.id.tvSceneBadge)
        tvHardwareHud = findViewById(R.id.tvHardwareHud)
        btnShutter = findViewById(R.id.btnShutter)
        btnSwitchLens = findViewById(R.id.btnSwitchCamera)
        btnOpenGallery = findViewById(R.id.btnOpenGallery)
        btnOpenEditor = findViewById(R.id.btnOpenEditor)
        seekZoom = findViewById(R.id.seekZoom)
        seekExposureEv = findViewById(R.id.seekExposureEv)

        // Initialize all 58-feature engines
        capabilitiesManager = CameraCapabilitiesManager(this)
        ringBufferManager = ZslRingBufferManager(maxCapacity = 12)
        computationalPipeline = ComputationalPipeline()
        nightAstroProcessor = NightAndAstroProcessor(computationalPipeline)
        superResProcessor = SuperResZoomProcessor(computationalPipeline)
        portraitFaceEngine = PortraitAndFaceEngine()
        smartAiEngine = SmartAiFeaturesEngine(portraitFaceEngine)
        magicEditorEngine = OfflineMagicEditorEngine(portraitFaceEngine)
        galleryManager = HighCapacityGalleryManager(this)

        cameraController = ProCamera2Controller(
            context = this,
            ringBufferManager = ringBufferManager,
            onGyroStabilityChanged = { gyroRad, isTripod ->
                runOnUiThread {
                    val stabTag = if (isTripod) "TRIPOD STABLE (Astro Ready)" else "HANDHELD (${"%.2f".format(gyroRad)} rad/s)"
                    val profile = cameraController.currentProfile
                    if (profile != null) {
                        tvHardwareHud.text = "${profile.halLevelName} | Zoom ${"%.1f".format(cameraController.controlState.zoomRatio)}x | $stabTag"
                    }
                }
            }
        )

        setupModeButtons()
        setupSlidersAndActions()

        if (hasRequiredPermissions()) {
            setupTextureView()
        } else {
            requestPermissionsForAndroid12To16()
        }
    }

    private fun setupModeButtons() {
        val modeButtons = mapOf(
            R.id.btnModeHdrPlus to CaptureMode.HDR_PLUS_PHOTO,
            R.id.btnModeNightSight to CaptureMode.NIGHT_SIGHT,
            R.id.btnModeAstro to CaptureMode.ASTROPHOTOGRAPHY,
            R.id.btnModePortrait to CaptureMode.PORTRAIT_BOKEH,
            R.id.btnModeSuperRes to CaptureMode.SUPER_RES_ZOOM,
            R.id.btnModeTopShot to CaptureMode.TOP_SHOT_MOTION,
            R.id.btnModeProRaw to CaptureMode.PRO_RAW_DNG
        )

        for ((btnId, mode) in modeButtons) {
            findViewById<Button>(btnId).setOnClickListener {
                val surf = previewSurface ?: return@setOnClickListener
                cameraController.updateControlState({ state ->
                    state.copy(
                        mode = mode,
                        enableRawDngOutput = (mode == CaptureMode.PRO_RAW_DNG),
                        enableMotionPhoto = (mode == CaptureMode.TOP_SHOT_MOTION)
                    )
                }, surf)
                Toast.makeText(this, "Active Mode: ${mode.name}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupSlidersAndActions() {
        // #21 Super Res Zoom, #22 Digital Zoom, #23 Optical Zoom
        seekZoom.max = 190 // 1.0x to 20.0x
        seekZoom.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val surf = previewSurface ?: return
                val zoomRatio = 1.0f + (progress / 10.0f)
                cameraController.updateControlState({ it.copy(zoomRatio = zoomRatio) }, surf)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // #11 Auto Exposure Compensation (-12 to +12)
        seekExposureEv.max = 24
        seekExposureEv.progress = 12
        seekExposureEv.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val surf = previewSurface ?: return
                val evIdx = progress - 12
                cameraController.updateControlState({ it.copy(exposureCompensationIndex = evIdx) }, surf)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // #40 Touch-to-Focus & #41 Tracking Autofocus
        textureView.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val surf = previewSurface ?: return@setOnTouchListener false
                val normX = (event.x / v.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                val normY = (event.y / v.height.coerceAtLeast(1)).coerceIn(0f, 1f)
                cameraController.setFocusAndTrackingRegion(normX, normY, surf)
                tvCoachBanner.text = "AF Locked & Tracking @ (${(normX * 100).toInt()}%, ${(normY * 100).toInt()}%)"
            }
            true
        }

        btnSwitchLens.setOnClickListener {
            isBackCamera = !isBackCamera
            startCameraSession()
        }

        btnOpenGallery.setOnClickListener {
            startActivity(Intent(this, GalleryActivity::class.java))
        }

        btnOpenEditor.setOnClickListener {
            val intent = Intent(this, EditorActivity::class.java)
            lastSavedFile?.let { intent.putExtra("PHOTO_PATH", it.absolutePath) }
            startActivity(intent)
        }

        btnShutter.setOnClickListener {
            captureAndProcessComputationalPhoto()
        }
    }

    /**
     * Executes the full 58-feature capture & offline processing pipeline based on the active mode!
     */
    private fun captureAndProcessComputationalPhoto() {
        val surf = previewSurface ?: return
        val shutterTimestampNs = System.nanoTime()
        btnShutter.isEnabled = false
        tvCoachBanner.text = "Capturing Multi-Frame Burst & Processing..."

        val mode = cameraController.controlState.mode
        val rawFile = if (mode == CaptureMode.PRO_RAW_DNG) {
            File(galleryManager.getAppPhotoDirectory(), "RAW_${System.currentTimeMillis()}.dng")
        } else null

        // Dispatch exposure-bracketed burst (#1 HDR+, #4/#50 RAW DNG)
        cameraController.triggerExposureBracketedBurst(
            previewSurface = surf,
            rawOutputFile = rawFile
        ) {
            lifecycleScope.launch(Dispatchers.Default) {
                // Gather ZSL & Burst frames from Circular Ring Buffer (#3 ZSL, #54 Buffer Management)
                val burstFrames = ringBufferManager.getZslBaseFrameAndBurst(
                    shutterTimestampNs = shutterTimestampNs,
                    burstCount = if (mode == CaptureMode.ASTROPHOTOGRAPHY) 10 else 6
                )

                if (burstFrames.isEmpty()) {
                    withContext(Dispatchers.Main) {
                        btnShutter.isEnabled = true
                        Toast.makeText(this@MainActivity, "Buffer warming up, tap shutter again!", Toast.LENGTH_SHORT).show()
                    }
                    return@launch
                }

                val processedBitmap: Bitmap = when (mode) {
                    CaptureMode.HDR_PLUS_PHOTO, CaptureMode.PRO_RAW_DNG -> {
                        // #1 HDR+, #2 Multi-frame, #5 Alignment, #6 Denoise, #7 Motion, #8 Deghost, #9 ToneMap, #10 Sharpen, #13-15
                        computationalPipeline.processHdrPlusBurst(burstFrames)
                    }
                    CaptureMode.NIGHT_SIGHT -> {
                        // #16 Night Sight, #18 Adaptive Exposure, #19 Night HDR
                        nightAstroProcessor.processNightSight(burstFrames)
                    }
                    CaptureMode.ASTROPHOTOGRAPHY -> {
                        // #17 Long Exposure & #20 Astrophotography
                        nightAstroProcessor.processAstrophotography(burstFrames)
                    }
                    CaptureMode.PORTRAIT_BOKEH -> {
                        // #26 Real Tone, #27 Face Detection, #28 Face Unblur, #29 Portrait, #30 Depth, #31 Segmentation, #32 Bokeh, #33 Retouch
                        val baseHdr = computationalPipeline.processHdrPlusBurst(burstFrames.take(3))
                        portraitFaceEngine.processPortraitMode(baseHdr)
                    }
                    CaptureMode.SUPER_RES_ZOOM -> {
                        // #21 Super Res Zoom, #24 Bicubic Upscaling, #25 Detail Reconstruction
                        superResProcessor.processSuperResZoom(
                            burstFrames,
                            zoomFactor = cameraController.controlState.zoomRatio.coerceAtLeast(2.0f)
                        )
                    }
                    CaptureMode.TOP_SHOT_MOTION -> {
                        // #35 Best Take + #36 Top Shot + #37 Motion Photos
                        val bestFrame = smartAiEngine.pickTopShotBestFrame(burstFrames) ?: burstFrames.first()
                        val bitmaps = burstFrames.take(4).map { it.toBitmap(step = 1) }
                        val bestTakeBmp = smartAiEngine.applyAutomaticBestTake(bitmaps)
                        bitmaps.forEach { if (it != bestTakeBmp && !it.isRecycled) it.recycle() }
                        computationalPipeline.applyToneMapColorAndSharpen(
                            bestTakeBmp,
                            com.proaicamera.gcamx.computational.HdrPlusConfig()
                        )
                    }
                }

                // #49 Attach Android 14–16 Ultra HDR Gainmap
                val finalHdrBitmap = magicEditorEngine.attachUltraHdrGainmapIfSupported(processedBitmap)

                // Save to High-Capacity Gallery (#50 JPEG / Ultra HDR)
                val savedFile = galleryManager.saveCapturedPhoto(
                    bitmap = finalHdrBitmap,
                    prefix = mode.name,
                    isUltraHdr = cameraController.controlState.enableUltraHdr
                )
                lastSavedFile = savedFile

                // #37 Save Motion Photo companion clip if in Top Shot / Motion mode
                if (mode == CaptureMode.TOP_SHOT_MOTION) {
                    ringBufferManager.exportMotionPhotoSequence(
                        galleryManager.getAppPhotoDirectory(),
                        savedFile.nameWithoutExtension
                    )
                }

                val totalPhotos = galleryManager.getTotalPhotoCount()
                withContext(Dispatchers.Main) {
                    btnShutter.isEnabled = true
                    btnOpenGallery.text = "Gallery ($totalPhotos)"
                    tvCoachBanner.text = "Saved: ${savedFile.name} (Tap 'AI Studio' to edit)"
                }
            }
        }
    }

    /**
     * Live #38 Camera Coach & #39 Scene Recognition background analyzer.
     */
    private fun startLiveAiCoachAndSceneLoop() {
        aiCoachJob?.cancel()
        aiCoachJob = lifecycleScope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(1800L)
                val latestFrame = ringBufferManager.getTopShotCandidates(1).firstOrNull() ?: continue
                val tinyBmp = latestFrame.toBitmap(step = 8)

                // #38 Camera Coach
                val coach = smartAiEngine.evaluateCameraCoach(
                    tinyBmp,
                    deviceRollDegrees = cameraController.latestGyroMagnitudeRadPerSec * 12f
                )

                // #39 Scene Recognition
                val scene = smartAiEngine.recognizeSceneBlocking(tinyBmp)
                tinyBmp.recycle()

                withContext(Dispatchers.Main) {
                    tvCoachBanner.text = coach.compositionTipHindi
                    tvSceneBadge.text = "Scene AI: ${scene.sceneCategory} • ${scene.recommendedPresetHint}"
                }
            }
        }
    }

    private fun setupTextureView() {
        if (textureView.isAvailable) {
            startCameraSession()
        } else {
            textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                    startCameraSession()
                }
                override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
                override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean = true
                override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
            }
        }
    }

    private fun startCameraSession() {
        val st = textureView.surfaceTexture ?: return
        st.setDefaultBufferSize(1920, 1440)
        val surf = Surface(st)
        previewSurface = surf

        val camId = if (isBackCamera) {
            capabilitiesManager.findPrimaryBackCameraId()
        } else {
            capabilitiesManager.findPrimaryFrontCameraId()
        }

        cameraController.openCamera(
            cameraId = camId,
            previewSurface = surf,
            onOpened = { profile ->
                runOnUiThread {
                    tvHardwareHud.text = "${profile.halLevelName} | RAW:${profile.supportsRawSensor} | UltraHDR:${profile.supportsUltraHdrJpegR}"
                    btnOpenGallery.text = "Gallery (${galleryManager.getTotalPhotoCount()})"
                }
                startLiveAiCoachAndSceneLoop()
            },
            onError = { err ->
                runOnUiThread {
                    Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                }
            }
        )
    }

    private fun hasRequiredPermissions(): Boolean {
        val camGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        return camGranted
    }

    private fun requestPermissionsForAndroid12To16() {
        val perms = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.READ_MEDIA_IMAGES)
            perms.add(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        ActivityCompat.requestPermissions(this, perms.toTypedArray(), 1001)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && hasRequiredPermissions()) {
            setupTextureView()
        }
    }

    override fun onDestroy() {
        aiCoachJob?.cancel()
        cameraController.stopBackgroundThread()
        super.onDestroy()
    }
}
