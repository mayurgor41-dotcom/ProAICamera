package com.proaicamera.gcamx.ui

import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.View

/**
 * Custom brush canvas for Magic Eraser / Magic Editor strokes.
 */
class BrushCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        // TODO: Draw brush strokes for inpainting mask
    }
}
