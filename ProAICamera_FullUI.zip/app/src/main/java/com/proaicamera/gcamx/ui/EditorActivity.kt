package com.proaicamera.gcamx.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.proaicamera.gcamx.R

class EditorActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor)
        // TODO: BrushCanvasView + Magic Eraser / Unblur / Ultra HDR tools
    }
}
