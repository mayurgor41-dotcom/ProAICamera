package com.proaicamera.gcamx.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.proaicamera.gcamx.R

class GalleryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)
        // TODO: HighCapacityGalleryManager + RecyclerView paging
    }
}
