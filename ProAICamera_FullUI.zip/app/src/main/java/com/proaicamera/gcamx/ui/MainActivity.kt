package com.proaicamera.gcamx.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import android.view.Surface
import android.view.TextureView
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.proaicamera.gcamx.R
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var textureView: TextureView
    private lateinit var tvSceneBadge: TextView
    private lateinit var tvCoachBanner: TextView
    private lateinit var ivGalleryThumb: ImageView

    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null
    private lateinit var cameraId: String
    private lateinit var previewSize: Size

    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null

    private var currentMode = "Photo"
    private var isFrontCamera = false
    private var lastPhotoPath: String? = null

    private val REQUEST_CAMERA = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textureView = findViewById(R.id.textureViewPreview)
        tvSceneBadge = findViewById(R.id.tvSceneBadge)
        tvCoachBanner = findViewById(R.id.tvCoachBanner)
        ivGalleryThumb = findViewById(R.id.ivGalleryThumb)

        setupTopBar()
        setupModes()
        setupBottomControls()

        updateModeUI("Photo")
        loadLastThumbnail()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA)
        }
    }

    override fun onResume() {
        super.onResume()
        startBackgroundThread()
        if (textureView.isAvailable) {
            openCamera()
        } else {
            textureView.surfaceTextureListener = surfaceTextureListener
        }
    }

    override fun onPause() {
        closeCamera()
        stopBackgroundThread()
        super.onPause()
    }

    private fun setupTopBar() {
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            SettingsBottomSheet().show(supportFragmentManager, "settings")
        }
        findViewById<ImageButton>(R.id.btnFlash).setOnClickListener {
            Toast.makeText(this, "Flash: Auto / On / Off", Toast.LENGTH_SHORT).show()
        }
        findViewById<ImageButton>(R.id.btnTimer).setOnClickListener {
            Toast.makeText(this, "Timer: Off / 3s / 10s", Toast.LENGTH_SHORT).show()
        }
        findViewById<ImageButton>(R.id.btnAspect).setOnClickListener {
            Toast.makeText(this, "Aspect: 4:3 / 16:9 / 1:1", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupModes() {
        findViewById<TextView>(R.id.modePhoto).setOnClickListener { updateModeUI("Photo") }
        findViewById<TextView>(R.id.modeNight).setOnClickListener { updateModeUI("Night Sight") }
        findViewById<TextView>(R.id.modePortrait).setOnClickListener { updateModeUI("Portrait") }
        findViewById<TextView>(R.id.modeAstro).setOnClickListener { updateModeUI("Astro") }
        findViewById<TextView>(R.id.modeRaw).setOnClickListener { updateModeUI("RAW") }
    }

    private fun setupBottomControls() {
        findViewById<Button>(R.id.btnShutter).setOnClickListener {
            takePicture()
        }

        ivGalleryThumb.setOnClickListener {
            if (lastPhotoPath != null) {
                Toast.makeText(this, "Opening last photo", Toast.LENGTH_SHORT).show()
                // startActivity(Intent(this, GalleryActivity::class.java))
            } else {
                Toast.makeText(this, "No photo yet", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<ImageButton>(R.id.btnSwitchCamera).setOnClickListener {
            isFrontCamera = !isFrontCamera
            closeCamera()
            openCamera()
            Toast.makeText(this, if (isFrontCamera) "Front camera" else "Back camera", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateModeUI(mode: String) {
        currentMode = mode
        tvSceneBadge.text = mode

        val modes = listOf(
            R.id.modePhoto to "Photo",
            R.id.modeNight to "Night Sight",
            R.id.modePortrait to "Portrait",
            R.id.modeAstro to "Astro",
            R.id.modeRaw to "RAW"
        )
        for ((id, name) in modes) {
            val tv = findViewById<TextView>(id)
            tv.setTextColor(if (name == mode) 0xFFFFFFFF.toInt() else 0xFFAAAAAA.toInt())
        }

        when (mode) {
            "Night Sight" -> {
                tvCoachBanner.text = "Hold steady • Low light mode"
                tvCoachBanner.setTextColor(0xFF58A6FF.toInt())
            }
            "Portrait" -> {
                tvCoachBanner.text = "Subject detected • Bokeh ready"
                tvCoachBanner.setTextColor(0xFFFF6B6B.toInt())
            }
            "Astro" -> {
                tvCoachBanner.text = "Point at stars • Keep still"
                tvCoachBanner.setTextColor(0xFFBB86FC.toInt())
            }
            else -> {
                tvCoachBanner.text = "Ready"
                tvCoachBanner.setTextColor(0xFF3FB950.toInt())
            }
        }
    }

    // -------------------- Camera2 Preview + Capture --------------------

    private val surfaceTextureListener = object : TextureView.SurfaceTextureListener {
        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
            openCamera()
        }
        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture) = true
        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
    }

    private fun openCamera() {
        val manager = getSystemService(CAMERA_SERVICE) as CameraManager
        try {
            cameraId = if (isFrontCamera) {
                manager.cameraIdList.firstOrNull { id ->
                    val chars = manager.getCameraCharacteristics(id)
                    chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
                } ?: manager.cameraIdList[0]
            } else {
                manager.cameraIdList.firstOrNull { id ->
                    val chars = manager.getCameraCharacteristics(id)
                    chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                } ?: manager.cameraIdList[0]
            }

            val characteristics = manager.getCameraCharacteristics(cameraId)
            val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            previewSize = map?.getOutputSizes(SurfaceTexture::class.java)?.maxByOrNull { it.width * it.height }
                ?: Size(1920, 1080)

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                return
            }
            manager.openCamera(cameraId, stateCallback, backgroundHandler)
        } catch (e: Exception) {
            Toast.makeText(this, "Camera open failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private val stateCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(camera: CameraDevice) {
            cameraDevice = camera
            createCameraPreview()
        }
        override fun onDisconnected(camera: CameraDevice) {
            camera.close()
            cameraDevice = null
        }
        override fun onError(camera: CameraDevice, error: Int) {
            camera.close()
            cameraDevice = null
        }
    }

    private fun createCameraPreview() {
        try {
            val texture = textureView.surfaceTexture
            texture?.setDefaultBufferSize(previewSize.width, previewSize.height)
            val surface = Surface(texture)

            imageReader = ImageReader.newInstance(previewSize.width, previewSize.height, ImageFormat.JPEG, 1)
            imageReader?.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage()
                val buffer = image.planes[0].buffer
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                saveImage(bytes)
                image.close()
            }, backgroundHandler)

            val previewRequestBuilder = cameraDevice!!.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            previewRequestBuilder.addTarget(surface)

            cameraDevice?.createCaptureSession(
                listOf(surface, imageReader!!.surface),
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        if (cameraDevice == null) return
                        captureSession = session
                        try {
                            previewRequestBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
                            session.setRepeatingRequest(previewRequestBuilder.build(), null, backgroundHandler)
                        } catch (e: Exception) { }
                    }
                    override fun onConfigureFailed(session: CameraCaptureSession) {}
                },
                backgroundHandler
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun takePicture() {
        if (cameraDevice == null || captureSession == null) {
            Toast.makeText(this, "Camera not ready", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val captureBuilder = cameraDevice!!.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            captureBuilder.addTarget(imageReader!!.surface)
            captureBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)

            when (currentMode) {
                "Night Sight" -> {
                    captureBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                    // Longer exposure simulation via lower sensitivity if possible
                }
                "Portrait" -> {
                    // Portrait would normally use depth; here just mark
                }
            }

            captureSession?.capture(captureBuilder.build(), null, backgroundHandler)
            tvCoachBanner.text = "Capturing..."
        } catch (e: Exception) {
            Toast.makeText(this, "Capture failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveImage(bytes: ByteArray) {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: filesDir
        val file = File(dir, "ProAI_$timeStamp.jpg")
        try {
            FileOutputStream(file).use { it.write(bytes) }
            lastPhotoPath = file.absolutePath
            runOnUiThread {
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ivGalleryThumb.setImageBitmap(bmp)
                tvCoachBanner.text = "Saved"
                Toast.makeText(this, "Photo saved", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadLastThumbnail() {
        val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: return
        val last = dir.listFiles()?.maxByOrNull { it.lastModified() }
        if (last != null && last.exists()) {
            lastPhotoPath = last.absolutePath
            val bmp = BitmapFactory.decodeFile(last.absolutePath)
            ivGalleryThumb.setImageBitmap(bmp)
        }
    }

    private fun closeCamera() {
        captureSession?.close()
        captureSession = null
        cameraDevice?.close()
        cameraDevice = null
        imageReader?.close()
        imageReader = null
    }

    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("CameraBackground").also { it.start() }
        backgroundHandler = Handler(backgroundThread!!.looper)
    }

    private fun stopBackgroundThread() {
        backgroundThread?.quitSafely()
        try {
            backgroundThread?.join()
            backgroundThread = null
            backgroundHandler = null
        } catch (e: InterruptedException) { }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            openCamera()
        }
    }
}
