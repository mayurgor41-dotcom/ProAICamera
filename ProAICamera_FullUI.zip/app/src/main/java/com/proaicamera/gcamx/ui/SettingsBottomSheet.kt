package com.proaicamera.gcamx.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Switch
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class SettingsBottomSheet : BottomSheetDialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(android.R.layout.simple_list_item_1, container, false)
        // Simple custom layout would be better, but for skeleton we use a basic view
        return createSettingsView()
    }

    private fun createSettingsView(): View {
        val context = requireContext()
        val layout = android.widget.LinearLayout(context).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(32, 32, 32, 48)
        }

        val title = android.widget.TextView(context).apply {
            text = "Pro AI Camera Settings"
            textSize = 18f
            setPadding(0, 0, 0, 24)
        }
        layout.addView(title)

        fun addSwitch(label: String, defaultOn: Boolean = false): Switch {
            val sw = Switch(context).apply {
                text = label
                isChecked = defaultOn
                setPadding(0, 12, 0, 12)
                setOnCheckedChangeListener { _, isChecked ->
                    Toast.makeText(context, "$label: ${if (isChecked) "ON" else "OFF"}", Toast.LENGTH_SHORT).show()
                }
            }
            layout.addView(sw)
            return sw
        }

        addSwitch("Grid lines", false)
        addSwitch("Leveler", false)
        addSwitch("HDR+ Auto", true)
        addSwitch("Save location", false)
        addSwitch("RAW on Pro mode", false)

        val closeBtn = android.widget.Button(context).apply {
            text = "Close"
            setOnClickListener { dismiss() }
        }
        layout.addView(closeBtn)

        return layout
    }
}
